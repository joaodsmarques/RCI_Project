# RCI_Project
Projeto de RCI para os orientarmos e partilharmos coisas de forma rapida e eficaz
